
package smartlibrarysystem;

public class SmartLibrarySystem {

    public static void main(String[] args) {
        // Set Nimbus look and feel
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // Falls back to default look and feel
        }

        // Launch the application starting from LoginFrame
        java.awt.EventQueue.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
