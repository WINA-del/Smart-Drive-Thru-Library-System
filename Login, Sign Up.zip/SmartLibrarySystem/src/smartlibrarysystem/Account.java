
package smartlibrarysystem;

public class Account {

    private String activeName;
    private String password;
    private boolean activStatus;
    private String activeNam;

    public Account() {}

    public Account(String activeNam, String password, boolean activStatus) {
        this.activeNam = activeNam;
        this.password = password;
        this.activStatus = activStatus;
    }

    // Getters & Setters
    public String getActiveNam() { return activeNam; }
    public void setActiveNam(String activeNam) { this.activeNam = activeNam; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public boolean isActivStatus() { return activStatus; }
    public void setActivStatus(boolean activStatus) { this.activStatus = activStatus; }

    public boolean isActive() { return activStatus; }

    public void activateAccount() { this.activStatus = true; }
    public void deactivateAccount() { this.activStatus = false; }

    public boolean walkTransfer(Account ack) {
        if (ack != null && ack.isActive()) {
            this.activeNam = ack.getActiveNam();
            this.password = ack.getPassword();
            this.activStatus = ack.isActivStatus();
            return true;
        }
        return false;
    }

    public void activateFlowword() {
        System.out.println("Account flow activated for: " + activeNam);
    }

    public void changeAccount() {
        System.out.println("Account changed for: " + activeNam);
    }

    public void changePassword(String newPassword) {
        this.password = newPassword;
        System.out.println("Password changed successfully.");
    }

    public boolean getActivenessStatus() { return activStatus; }
}