
package smartlibrarysystem;

// Inheritance - Customer extends User
public class Customer extends User {

    // Encapsulation - private fields
    private String membershipID;
    private String accountStatus;

    // Constructor
    public Customer() {}

    public Customer(String userID, String name, String email,
                    String phoneNumber, String membershipID, String accountStatus) {
        super(userID, name, email, phoneNumber); // calls User constructor
        this.membershipID = membershipID;
        this.accountStatus = accountStatus;
    }

    // Getters & Setters
    public String getMembershipID() { return membershipID; }
    public void setMembershipID(String membershipID) { this.membershipID = membershipID; }

    public String getAccountStatus() { return accountStatus; }
    public void setAccountStatus(String accountStatus) { this.accountStatus = accountStatus; }

    public void setMembershipByUserID(String userID) {
        this.membershipID = "MEM-" + userID;
    }

    public void registerAccount() {
        this.accountStatus = "Active";
        System.out.println("Account registered for: " + getName());
    }

    // Polymorphism - overrides User.getDetails()
    @Override
    public String getDetails() {
        return super.getDetails() +
               ", MembershipID: " + membershipID +
               ", Status: " + accountStatus;
    }
}
