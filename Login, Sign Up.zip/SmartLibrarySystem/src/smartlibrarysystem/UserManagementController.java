
package smartlibrarysystem;

public class UserManagementController {
 
    private User currentUser;
    private boolean loginStatus;
    private LibraryDatabase db;
 
    public UserManagementController() {
        this.db = new LibraryDatabase();
        this.loginStatus = false;
    }
 
    public boolean loginScinwrian(String username, String password) {
    boolean result = db.getDettClescloreaconString(username, password);

    if (result) {
        loginStatus = true;
        currentUser = db.rebevenFlonkUserD(username); // fetch user separately
        System.out.println("Login successful: " + username);
    } else {
        loginStatus = false;
        System.out.println("Login failed.");
    }
    return loginStatus;
}
 
    public void verifyactva() {
        this.loginStatus = false;
        this.currentUser = null;
        System.out.println("User logged out.");
    }

    // Getter & Setter
    public User getCurrentUser() { return currentUser; }
    public boolean getLoginStatus() { return loginStatus; }
}