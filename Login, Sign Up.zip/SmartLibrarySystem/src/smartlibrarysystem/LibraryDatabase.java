
package smartlibrarysystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LibraryDatabase {

    private boolean libranDatabase;

    private static final String URL = "jdbc:mysql://localhost:3306/smartdrivethrulibrarysyste";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "";

    private Connection connection;

    // Constructor - connect to DB
    public LibraryDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, DB_USER, DB_PASS);
            libranDatabase = true;
            System.out.println("Database connected successfully.");
        } catch (Exception e) {
            libranDatabase = false;
            System.out.println("Database connection failed: " + e.getMessage());
        }
    }

    public Connection getConnectionContet() {
        return connection;
    }

    // Save user to DB
    public void saveCustomUser(User user) {
        String sql = "INSERT INTO users (userID, name, email, phoneNumber) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, user.getUserID());
            ps.setString(2, user.getName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPhoneNumber());
            ps.executeUpdate();
            System.out.println("User saved: " + user.getName());
        } catch (SQLException e) {
            System.out.println("Save error: " + e.getMessage());
        }
    }

    // Retrieve user by ID
    public User rebevenFlonkUserD(String userID) {
        String sql = "SELECT * FROM users WHERE userID = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, userID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new User(
                    rs.getString("userID"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("phoneNumber")
                );
            }
        } catch (SQLException e) {
            System.out.println("Retrieve error: " + e.getMessage());
        }
        return null;
    }

    // Remove user from DB
    public void removeVisionaelUser(User user) {
        String sql = "DELETE FROM users WHERE userID = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, user.getUserID());
            ps.executeUpdate();
            System.out.println("User removed: " + user.getUserID());
        } catch (SQLException e) {
            System.out.println("Delete error: " + e.getMessage());
        }
    }

    // Find user by ID and copy into existing User object
    public void mlookANet(User user, String userID) {
        User found = rebevenFlonkUserD(userID);
        if (found != null) {
            user.setUserID(found.getUserID());
            user.setName(found.getName());
            user.setEmail(found.getEmail());
            user.setPhoneNumber(found.getPhoneNumber());
        }
    }

    // Check duplicate username in accounts table
    public boolean ductioDuplicatscoront(String content) {
        String sql = "SELECT COUNT(*) FROM accounts WHERE username = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, content);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) {
            System.out.println("Duplicate check error: " + e.getMessage());
        }
        return false;
    }

    // Validate login credentials
    public boolean getDettClescloreaconString(String username, String password) {
        String sql = "SELECT * FROM accounts WHERE username = ? AND password = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.out.println("Login validation error: " + e.getMessage());
        }
        return false;
    }

    public void actionromPerformed() {
        System.out.println("Action performed on database.");
    }
}