
package smartlibrarysystem;

public class User {

    // Encapsulation - private fields
    private String userID;
    private String name;
    private String email;
    private String phoneNumber;
    private Account account;

    // Constructor
    public User() {}

    public User(String userID, String name, String email, String phoneNumber) {
        this.userID = userID;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    // Getters & Setters
    public String getUserID() { return userID; }
    public void setUserID(String userID) { this.userID = userID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public Account getAccount() { return account; }
    public void setAccount(Account account) { this.account = account; }

    public void getAccountIntoJson(Account account) {
        this.account = account;
    }

    // Polymorphism - overridden in subclasses
    public String getDetails() {
        return "UserID: " + userID + ", Name: " + name +
               ", Email: " + email + ", Phone: " + phoneNumber;
    }
}