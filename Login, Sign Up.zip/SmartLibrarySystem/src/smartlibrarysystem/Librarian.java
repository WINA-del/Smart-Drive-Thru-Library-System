
package smartlibrarysystem;

// Inheritance - Librarian extends User
public class Librarian extends User {

    // Encapsulation - private fields
    private String employeeID;
    private String role = "LIBRARIAN";

    // Constructor
    public Librarian() {}

    public Librarian(String userID, String name, String email,
                     String phoneNumber, String employeeID) {
        super(userID, name, email, phoneNumber); // calls User constructor
        this.employeeID = employeeID;
        this.role = "LIBRARIAN";
    }

    // Getters & Setters
    public String getEmployeeID() { return employeeID; }
    public void setEmployeeID(String employeeID) { this.employeeID = employeeID; }

    public String getRole() { return role; }

    public void setEmployeeByEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public void manageAccount() {
        System.out.println("Librarian " + getName() + " is managing accounts.");
    }

    public void manageIssuing() {
        System.out.println("Librarian " + getName() + " is managing book issuing.");
    }

    // Polymorphism - overrides User.getDetails()
    @Override
    public String getDetails() {
        return super.getDetails() +
               ", EmployeeID: " + employeeID +
               ", Role: " + role;
    }
}