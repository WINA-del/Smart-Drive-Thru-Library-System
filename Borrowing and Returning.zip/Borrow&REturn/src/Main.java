import java.util.*;

/**
 * Smart Drive-Thru Library System
 * Module : Borrow & Return (MySQL-backed — database: library_system)
 * ─────────────────────────────────────────────────────────────────
 * OOP Concepts demonstrated:
 *   Encapsulation  — private fields, accessed via getters/setters
 *   Inheritance    — Customer and Librarian extend User
 *   Polymorphism   — getDetails() overridden in each subclass
 *   Abstraction    — User is abstract
 *   Composition    — BorrowRecord owns Fine
 *   Aggregation    — Customer associated with Reservation
 * ─────────────────────────────────────────────────────────────────
 */
public class Main {

    static Librarian librarian;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        librarian = new Librarian("L-001", "Puan Siti", "siti@library.edu.my",
                "011-1234567", "Borrow & Return");

        System.out.println("\n  ╔══════════════════════════════════════════╗");
        System.out.println("  ║    SMART DRIVE-THRU LIBRARY SYSTEM       ║");
        System.out.println("  ║    Borrow & Return Module (library_system)║");
        System.out.println("  ╚══════════════════════════════════════════╝");

        mainMenu();
        DBConnection.close();
    }

    static void mainMenu() {
        while (true) {
            System.out.println("\n  ┌──────────────────────────────┐");
            System.out.println("  │         MAIN MENU             │");
            System.out.println("  ├──────────────────────────────┤");
            System.out.println("  │  1. Borrow a Book             │");
            System.out.println("  │  2. Return a Book             │");
            System.out.println("  │  3. Reserve a Book            │");
            System.out.println("  │  4. Pay Fine                  │");
            System.out.println("  │  5. View Customer Details     │");
            System.out.println("  │  6. View All Books            │");
            System.out.println("  │  7. View All Borrow Records   │");
            System.out.println("  │  8. Librarian: Exempt Fine    │");
            System.out.println("  │  0. Exit                      │");
            System.out.println("  └──────────────────────────────┘");
            System.out.print("  Choose: ");

            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1": borrowMenu();    break;
                case "2": returnMenu();    break;
                case "3": reserveMenu();   break;
                case "4": payFineMenu();   break;
                case "5": viewCustomer();  break;
                case "6": listBooks();     break;
                case "7": listRecords();   break;
                case "8": exemptMenu();    break;
                case "0":
                    System.out.println("\n  Goodbye! Thank you for using the Drive-Thru Library.\n");
                    return;
                default:
                    System.out.println("  Invalid option. Try again.");
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    static void borrowMenu() {
        System.out.println("\n  ── BORROW A BOOK ─────────────────────────");

        Customer customer = selectCustomer();
        if (customer == null) return;

        System.out.println("\n" + customer.getDetails());

        Book book = selectBook(true);
        if (book == null) return;

        BorrowRecord record = customer.borrowBook(book);
        if (record != null) {
            System.out.println("\n  ✔ Borrow successful! (saved to library_system)");
            librarian.printReceipt(record);
        }
    }

    // ══════════════════════════════════════════════════════════════
    static void returnMenu() {
        System.out.println("\n  ── RETURN A BOOK ─────────────────────────");

        Customer customer = selectCustomer();
        if (customer == null) return;

        List<BorrowRecord> active = BorrowRecord.getActiveByCustomer(customer);

        if (active.isEmpty()) {
            System.out.println("  No active borrows found for this customer.");
            return;
        }

        System.out.println("\n  Active borrows:");
        for (int i = 0; i < active.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + active.get(i));
        }
        System.out.print("  Select record number: ");
        int idx = readInt(1, active.size());
        if (idx == -1) return;

        BorrowRecord record = active.get(idx - 1);
        Fine fine = customer.returnBook(record);

        System.out.println("\n  ✔ Return processed! (saved to library_system)");
        librarian.printReturnReceipt(record);

        if (fine != null) {
            System.out.println("\n  ⚠ Overdue fine of RM "
                    + String.format("%.2f", fine.getAmount()) + " added to account.");
            System.out.println("  Days overdue: " + fine.getOverdueDays());
            if (fine.isCapped()) System.out.println("  (Fine has been capped at RM 20.00)");
        }
    }

    // ══════════════════════════════════════════════════════════════
    static void reserveMenu() {
        System.out.println("\n  ── RESERVE A BOOK ────────────────────────");

        Customer customer = selectCustomer();
        if (customer == null) return;

        Book book = selectBook(false);
        if (book == null) return;

        Reservation res = customer.reserveBook(book);
        if (res != null) {
            System.out.println("\n  ✔ Reservation confirmed! (saved to library_system)");
            System.out.println("  Reservation ID : " + res.getReserveID());
            System.out.println("  Book           : " + book.getTitle());
            System.out.println("  Expires        : " + res.getExpiryDate());
        }
    }

    // ══════════════════════════════════════════════════════════════
    static void payFineMenu() {
        System.out.println("\n  ── PAY FINE ──────────────────────────────");

        Customer customer = selectCustomer();
        if (customer == null) return;

        if (customer.getTotalFines() == 0) {
            System.out.println("  No outstanding fines for this customer.");
            return;
        }

        List<BorrowRecord> all = BorrowRecord.getAllByCustomer(customer);
        List<BorrowRecord> fined = new ArrayList<>();
        for (BorrowRecord r : all) {
            Fine f = Fine.getByRecordId(r.getRecordID());
            if (f != null && !f.isPaid() && !f.isExempted()) {
                r.attachFine(f);
                fined.add(r);
            }
        }

        if (fined.isEmpty()) {
            System.out.println("  No unpaid fines found.");
            return;
        }

        System.out.println("\n  Records with unpaid fines:");
        for (int i = 0; i < fined.size(); i++) {
            System.out.printf("  %d. %s | Fine: RM %.2f%n",
                    i + 1, fined.get(i).getRecordID(), fined.get(i).getFine().getAmount());
        }
        System.out.print("  Select record to pay: ");
        int idx = readInt(1, fined.size());
        if (idx == -1) return;

        customer.payFine(fined.get(idx - 1));
        System.out.printf("  ✔ Payment recorded. Remaining balance: RM %.2f%n", customer.getTotalFines());
    }

    // ══════════════════════════════════════════════════════════════
    static void viewCustomer() {
        System.out.println("\n  ── CUSTOMER DETAILS ──────────────────────");
        Customer customer = selectCustomer();
        if (customer == null) return;

        System.out.println("\n" + customer.getDetails());

        System.out.println("\n  Borrow History:");
        List<BorrowRecord> history = BorrowRecord.getAllByCustomer(customer);
        if (history.isEmpty()) {
            System.out.println("  (none)");
        } else {
            for (BorrowRecord r : history) System.out.println("  " + r);
        }

        System.out.println("\n  Reservations:");
        List<Reservation> reservations = Reservation.getByCustomer(customer);
        if (reservations.isEmpty()) {
            System.out.println("  (none)");
        } else {
            for (Reservation r : reservations) System.out.println("  " + r);
        }
    }

    // ══════════════════════════════════════════════════════════════
    static void listBooks() {
        System.out.println("\n  ── BOOK CATALOGUE ────────────────────────");
        System.out.printf("  %-8s %-28s %-20s %s%n", "ID", "Title", "Author", "Status");
        System.out.println("  " + "─".repeat(68));
        for (Book b : Book.getAll()) {
            System.out.println("  " + b);
        }
    }

    // ══════════════════════════════════════════════════════════════
    static void listRecords() {
        System.out.println("\n  ── ALL BORROW RECORDS ────────────────────");
        List<BorrowRecord> all = BorrowRecord.getAll();
        if (all.isEmpty()) {
            System.out.println("  No records yet.");
            return;
        }
        for (BorrowRecord r : all) {
            Fine f = Fine.getByRecordId(r.getRecordID());
            if (f != null) r.attachFine(f);
            System.out.println("\n" + r.getSummary());
        }
    }

    // ══════════════════════════════════════════════════════════════
    static void exemptMenu() {
        System.out.println("\n  ── LIBRARIAN: EXEMPT FINE ────────────────");
        System.out.println("  Logged in as: " + librarian.getName());

        Customer customer = selectCustomer();
        if (customer == null) return;

        List<BorrowRecord> all = BorrowRecord.getAllByCustomer(customer);
        List<BorrowRecord> fined = new ArrayList<>();
        for (BorrowRecord r : all) {
            Fine f = Fine.getByRecordId(r.getRecordID());
            if (f != null && !f.isPaid() && !f.isExempted()) {
                r.attachFine(f);
                fined.add(r);
            }
        }

        if (fined.isEmpty()) {
            System.out.println("  No fines to exempt.");
            return;
        }

        System.out.println("\n  Records with fines:");
        for (int i = 0; i < fined.size(); i++) {
            System.out.printf("  %d. %s | Fine: RM %.2f%n",
                    i + 1, fined.get(i).getRecordID(), fined.get(i).getFine().getAmount());
        }
        System.out.print("  Select record to exempt: ");
        int idx = readInt(1, fined.size());
        if (idx == -1) return;

        librarian.exemptFine(customer, fined.get(idx - 1));
        System.out.println("  ✔ Fine exempted successfully. (saved to library_system)");
    }

    // ══════════════════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════════════════
    static Customer selectCustomer() {
        List<Customer> customers = Customer.getAll();
        System.out.println("\n  Customers:");
        for (int i = 0; i < customers.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + customers.get(i));
        }
        System.out.print("  Select customer number (0 to cancel): ");
        int idx = readInt(0, customers.size());
        if (idx <= 0) return null;
        return customers.get(idx - 1);
    }

    static Book selectBook(boolean availableOnly) {
        List<Book> books = availableOnly ? Book.getAvailable() : Book.getAll();

        if (books.isEmpty()) {
            System.out.println("  No books available.");
            return null;
        }
        System.out.println("\n  Books:");
        for (int i = 0; i < books.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + books.get(i));
        }
        System.out.print("  Select book number (0 to cancel): ");
        int idx = readInt(0, books.size());
        if (idx <= 0) return null;
        return books.get(idx - 1);
    }

    static int readInt(int min, int max) {
        try {
            int val = Integer.parseInt(sc.nextLine().trim());
            if (val >= min && val <= max) return val;
            System.out.println("  Please enter a number between " + min + " and " + max);
            return -1;
        } catch (NumberFormatException e) {
            System.out.println("  Invalid input.");
            return -1;
        }
    }
}
