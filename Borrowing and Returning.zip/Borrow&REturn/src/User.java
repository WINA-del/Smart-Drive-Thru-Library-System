// Abstract parent class — INHERITANCE base for Customer and Librarian
public abstract class User {

    private String userID;
    private String name;
    private String email;
    private String phone;

    public User(String userID, String name, String email, String phone) {
        this.userID = userID;
        this.name   = name;
        this.email  = email;
        this.phone  = phone;
    }

    // ABSTRACTION — forces subclasses to implement their own version
    public abstract String getDetails();

    public String getUserID() { return userID; }
    public String getName()   { return name; }
    public String getEmail()  { return email; }
    public String getPhone()  { return phone; }

    @Override
    public String toString() {
        return "[" + userID + "] " + name;
    }
}
