import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// INHERITANCE — Customer extends User
public class Customer extends User {

    private String  customerID;
    private int     borrowLimit;
    private double  totalFines;
    private boolean isBlocked;

    // New customer — defaults applied
    public Customer(String customerID, String name, String email, String phone) {
        super(customerID, name, email, phone);
        this.customerID  = customerID;
        this.borrowLimit = 5;
        this.totalFines  = 0.0;
        this.isBlocked   = false;
    }

    // Used when loading an existing customer from the database
    public Customer(String customerID, String name, String email, String phone,
                     int borrowLimit, double totalFines, boolean isBlocked) {
        super(customerID, name, email, phone);
        this.customerID  = customerID;
        this.borrowLimit = borrowLimit;
        this.totalFines  = totalFines;
        this.isBlocked   = isBlocked;
    }

    // ── BORROW / RETURN / RESERVE / FINE LOGIC ───────────────────

    public BorrowRecord borrowBook(Book book) {
        int activeCount = BorrowRecord.countActiveBorrows(customerID);

        if (isBlocked) {
            System.out.println("  ERROR: Account blocked — settle RM "
                    + String.format("%.2f", totalFines) + " in fines first.");
            return null;
        }
        if (activeCount >= borrowLimit) {
            System.out.println("  ERROR: Borrow limit of " + borrowLimit + " reached.");
            return null;
        }
        if (!book.isAvailable()) {
            System.out.println("  ERROR: Book is not available — status: " + book.getStatus());
            return null;
        }

        String recordID = BorrowRecord.generateNextID();
        BorrowRecord record = new BorrowRecord(recordID, this, book);
        record.save();                       // INSERT into borrow_record

        book.setStatus(BookStatus.BORROWED);
        book.updateStatus();                 // UPDATE book table

        return record;
    }

    public Fine returnBook(BorrowRecord record) {
        if (record.isClosed()) {
            System.out.println("  ERROR: This record is already closed.");
            return null;
        }

        record.closeRecord();
        record.updateOnReturn();             // UPDATE borrow_record table

        record.getBook().setStatus(BookStatus.AVAILABLE);
        record.getBook().updateStatus();     // UPDATE book table

        Fine fine = null;
        if (record.isOverdue()) {
            String fineID = "FINE-" + record.getRecordID();
            fine = record.generateFine(fineID);
            fine.save();                     // INSERT into fine table

            totalFines += fine.getAmount();
            updateBlockStatus();
            saveFinesAndBlock();             // UPDATE customer table
        }
        return fine;
    }

    public Reservation reserveBook(Book book) {
        if (book.isAvailable()) {
            System.out.println("  Book is available — borrow it directly instead.");
            return null;
        }
        if (isBlocked) {
            System.out.println("  ERROR: Account blocked — cannot make reservation.");
            return null;
        }

        String reserveID = Reservation.generateNextID();
        Reservation res = new Reservation(reserveID, this, book);
        res.save();                          // INSERT into reservation table

        book.setStatus(BookStatus.RESERVED);
        book.updateStatus();                 // UPDATE book table

        return res;
    }

    public void payFine(BorrowRecord record) {
        Fine fine = Fine.getByRecordId(record.getRecordID());
        if (fine == null) {
            System.out.println("  No fine found on this record.");
            return;
        }
        if (fine.isPaid()) {
            System.out.println("  Fine already paid.");
            return;
        }

        fine.markPaid();
        fine.updateState();                  // UPDATE fine table

        totalFines -= fine.getAmount();
        if (totalFines < 0) totalFines = 0;
        updateBlockStatus();
        saveFinesAndBlock();                 // UPDATE customer table
    }

    protected void updateBlockStatus() {
        isBlocked = (totalFines > 0);
    }

    // Called by Librarian when exempting a fine — removes amount from balance
    public void deductFine(double amount) {
        totalFines -= amount;
        if (totalFines < 0) totalFines = 0;
        updateBlockStatus();
        saveFinesAndBlock();                 // UPDATE customer table
    }

    // ── DATABASE METHODS ─────────────────────────────────────────

    public void saveFinesAndBlock() {
        String sql = "UPDATE customer SET total_fines = ?, is_blocked = ? WHERE customer_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, totalFines);
            ps.setBoolean(2, isBlocked);
            ps.setString(3, customerID);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("  DB error (Customer.saveFinesAndBlock): " + e.getMessage());
        }
    }

    public static List<Customer> getAll() {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM customer";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) list.add(mapRow(rs));

        } catch (SQLException e) {
            System.out.println("  DB error (Customer.getAll): " + e.getMessage());
        }
        return list;
    }

    public static Customer getById(String customerID) {
        String sql = "SELECT * FROM customer WHERE customer_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, customerID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);

        } catch (SQLException e) {
            System.out.println("  DB error (Customer.getById): " + e.getMessage());
        }
        return null;
    }

    private static Customer mapRow(ResultSet rs) throws SQLException {
        return new Customer(
                rs.getString("customer_id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("phone"),
                rs.getInt("borrow_limit"),
                rs.getDouble("total_fines"),
                rs.getBoolean("is_blocked")
        );
    }

    // ── GETTERS ────────────────────────────────────────────────
    public String  getCustomerID()  { return customerID; }
    public int     getBorrowLimit() { return borrowLimit; }
    public double  getTotalFines()  { return totalFines; }
    public boolean isBlocked()      { return isBlocked; }

    // POLYMORPHISM — overrides abstract method in User
    @Override
    public String getDetails() {
        return String.format(
                "  Customer ID  : %s%n  Name         : %s%n  Email        : %s%n" +
                "  Phone        : %s%n  Borrow limit : %d%n" +
                "  Fines        : RM %.2f%n  Blocked      : %s",
                customerID, getName(), getEmail(), getPhone(),
                borrowLimit, totalFines, isBlocked ? "YES" : "NO"
        );
    }

    @Override
    public String toString() {
        return "[" + customerID + "] " + getName() + (isBlocked ? " [BLOCKED]" : "");
    }
}
