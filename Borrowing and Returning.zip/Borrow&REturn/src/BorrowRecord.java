import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

// Tracks one borrowing transaction — COMPOSITION: owns a Fine
public class BorrowRecord {

    private String    recordID;
    private Customer  customer;
    private Book      book;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private boolean   isClosed;
    private Fine      fine;

    // New record — not yet in database
    public BorrowRecord(String recordID, Customer customer, Book book) {
        this.recordID   = recordID;
        this.customer   = customer;
        this.book       = book;
        this.borrowDate = LocalDate.now();
        this.dueDate    = borrowDate.plusDays(14);
        this.isClosed   = false;
        this.fine       = null;
    }

    // Used when loading an existing record from the database
    public BorrowRecord(String recordID, Customer customer, Book book,
                         LocalDate borrowDate, LocalDate dueDate,
                         LocalDate returnDate, boolean isClosed) {
        this.recordID   = recordID;
        this.customer   = customer;
        this.book       = book;
        this.borrowDate = borrowDate;
        this.dueDate    = dueDate;
        this.returnDate = returnDate;
        this.isClosed   = isClosed;
        this.fine       = null;
    }

    public void closeRecord() {
        returnDate = LocalDate.now();
        isClosed   = true;
    }

    public boolean isOverdue() {
        LocalDate checkDate = (returnDate != null) ? returnDate : LocalDate.now();
        return checkDate.isAfter(dueDate);
    }

    public int getDaysOverdue() {
        if (!isOverdue()) return 0;
        LocalDate checkDate = (returnDate != null) ? returnDate : LocalDate.now();
        return (int) ChronoUnit.DAYS.between(dueDate, checkDate);
    }

    public Fine generateFine(String fineID) {
        if (fine == null && isOverdue()) fine = new Fine(fineID, recordID, getDaysOverdue());
        return fine;
    }

    public void attachFine(Fine fine) { this.fine = fine; }

    // ── DATABASE METHODS ─────────────────────────────────────────

    public static String generateNextID() {
        String sql = "SELECT COUNT(*) AS total FROM borrow_record";
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) count = rs.getInt("total");
        } catch (SQLException e) {
            System.out.println("  DB error (generateNextID): " + e.getMessage());
        }
        return String.format("REC-%03d", count + 1);
    }

    public void save() {
        String sql = "INSERT INTO borrow_record (record_id, customer_id, book_id, borrow_date, due_date, return_date, is_closed) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, recordID);
            ps.setString(2, customer.getCustomerID());
            ps.setString(3, book.getBookID());
            ps.setDate(4, Date.valueOf(borrowDate));
            ps.setDate(5, Date.valueOf(dueDate));
            ps.setDate(6, returnDate != null ? Date.valueOf(returnDate) : null);
            ps.setBoolean(7, isClosed);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("  DB error (BorrowRecord.save): " + e.getMessage());
        }
    }

    public void updateOnReturn() {
        String sql = "UPDATE borrow_record SET return_date = ?, is_closed = ? WHERE record_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(returnDate));
            ps.setBoolean(2, true);
            ps.setString(3, recordID);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("  DB error (BorrowRecord.updateOnReturn): " + e.getMessage());
        }
    }

    public static List<BorrowRecord> getActiveByCustomer(Customer customer) {
        return query("SELECT * FROM borrow_record WHERE customer_id = ? AND is_closed = FALSE", customer);
    }

    public static List<BorrowRecord> getAllByCustomer(Customer customer) {
        return query("SELECT * FROM borrow_record WHERE customer_id = ?", customer);
    }

    public static List<BorrowRecord> getAll() {
        List<BorrowRecord> list = new ArrayList<>();
        String sql = "SELECT * FROM borrow_record";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Customer c = Customer.getById(rs.getString("customer_id"));
                Book      b = Book.getById(rs.getString("book_id"));
                list.add(mapRow(rs, c, b));
            }
        } catch (SQLException e) {
            System.out.println("  DB error (BorrowRecord.getAll): " + e.getMessage());
        }
        return list;
    }

    public static int countActiveBorrows(String customerID) {
        String sql = "SELECT COUNT(*) AS total FROM borrow_record WHERE customer_id = ? AND is_closed = FALSE";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, customerID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("total");
        } catch (SQLException e) {
            System.out.println("  DB error (countActiveBorrows): " + e.getMessage());
        }
        return 0;
    }

    private static List<BorrowRecord> query(String sql, Customer customer) {
        List<BorrowRecord> list = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, customer.getCustomerID());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Book b = Book.getById(rs.getString("book_id"));
                list.add(mapRow(rs, customer, b));
            }
        } catch (SQLException e) {
            System.out.println("  DB error (BorrowRecord.query): " + e.getMessage());
        }
        return list;
    }

    private static BorrowRecord mapRow(ResultSet rs, Customer customer, Book book) throws SQLException {
        Date returnDate = rs.getDate("return_date");
        return new BorrowRecord(
                rs.getString("record_id"), customer, book,
                rs.getDate("borrow_date").toLocalDate(),
                rs.getDate("due_date").toLocalDate(),
                returnDate != null ? returnDate.toLocalDate() : null,
                rs.getBoolean("is_closed")
        );
    }

    // ── GETTERS ────────────────────────────────────────────────
    public String    getRecordID()   { return recordID; }
    public Customer  getCustomer()   { return customer; }
    public Book      getBook()       { return book; }
    public LocalDate getBorrowDate() { return borrowDate; }
    public LocalDate getDueDate()    { return dueDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public boolean   isClosed()      { return isClosed; }
    public Fine      getFine()       { return fine; }

    public String getSummary() {
        String status = isClosed ? (isOverdue() ? "RETURNED-LATE" : "RETURNED")
                                  : (isOverdue() ? "OVERDUE" : "ACTIVE");
        String fineLine = (fine != null)
                ? String.format("  Fine      : RM %.2f (%s)%n", fine.getAmount(),
                    fine.isPaid() ? "PAID" : fine.isExempted() ? "EXEMPTED" : "UNPAID")
                : "";
        return String.format(
                "  Record ID : %s%n  Book      : %s%n  Customer  : %s%n" +
                "  Borrowed  : %s%n  Due Date  : %s%n  Returned  : %s%n  Status    : %s%n%s",
                recordID, book.getTitle(), customer.getName(), borrowDate, dueDate,
                returnDate != null ? returnDate : "-", status, fineLine
        );
    }

    @Override
    public String toString() {
        return recordID + " | " + book.getTitle() + " | Due: " + dueDate
                + " | " + (isClosed ? "CLOSED" : isOverdue() ? "OVERDUE" : "ACTIVE");
    }
}
