// INHERITANCE — Librarian extends User
public class Librarian extends User {

    private String staffID;
    private String department;

    public Librarian(String staffID, String name, String email, String phone, String department) {
        super(staffID, name, email, phone);
        this.staffID    = staffID;
        this.department = department;
    }

    // Exempt a fine (librarian privilege)
    public void exemptFine(Customer customer, BorrowRecord record) {
        Fine fine = Fine.getByRecordId(record.getRecordID());
        if (fine == null) {
            System.out.println("  No fine to exempt.");
            return;
        }

        fine.applyExemption();
        fine.updateState();                  // UPDATE fine table

        // Remove the exempted amount from the customer's outstanding balance
        customer.deductFine(fine.getAmount());

        System.out.println("  Exemption granted by Librarian " + getName());
    }

    public void printReceipt(BorrowRecord record) {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════╗");
        System.out.println("  ║   SMART DRIVE-THRU LIBRARY SYSTEM    ║");
        System.out.println("  ║          BORROW RECEIPT               ║");
        System.out.println("  ╠══════════════════════════════════════╣");
        System.out.printf ("  ║  Record  : %-26s║%n", record.getRecordID());
        System.out.printf ("  ║  Customer: %-26s║%n", record.getCustomer().getName());
        System.out.printf ("  ║  Book    : %-26s║%n", record.getBook().getTitle());
        System.out.printf ("  ║  Borrow  : %-26s║%n", record.getBorrowDate());
        System.out.printf ("  ║  Due     : %-26s║%n", record.getDueDate());
        System.out.printf ("  ║  Staff   : %-26s║%n", getName());
        System.out.println("  ╚══════════════════════════════════════╝");
    }

    public void printReturnReceipt(BorrowRecord record) {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════╗");
        System.out.println("  ║   SMART DRIVE-THRU LIBRARY SYSTEM    ║");
        System.out.println("  ║          RETURN RECEIPT               ║");
        System.out.println("  ╠══════════════════════════════════════╣");
        System.out.printf ("  ║  Record  : %-26s║%n", record.getRecordID());
        System.out.printf ("  ║  Customer: %-26s║%n", record.getCustomer().getName());
        System.out.printf ("  ║  Book    : %-26s║%n", record.getBook().getTitle());
        System.out.printf ("  ║  Due     : %-26s║%n", record.getDueDate());
        System.out.printf ("  ║  Returned: %-26s║%n", record.getReturnDate());
        Fine f = record.getFine();
        if (f != null) {
            String state = f.isExempted() ? " (EXEMPTED)" : f.isPaid() ? " (PAID)" : " (UNPAID)";
            System.out.printf("  ║  Fine    : RM %-23s║%n", String.format("%.2f", f.getAmount()) + state);
        } else {
            System.out.printf("  ║  Fine    : %-26s║%n", "None");
        }
        System.out.printf ("  ║  Staff   : %-26s║%n", getName());
        System.out.println("  ╚══════════════════════════════════════╝");
    }

    public String getStaffID()    { return staffID; }
    public String getDepartment() { return department; }

    // POLYMORPHISM — overrides abstract method in User
    @Override
    public String getDetails() {
        return String.format("  Staff ID   : %s%n  Name       : %s%n  Department : %s",
                staffID, getName(), department);
    }
}
