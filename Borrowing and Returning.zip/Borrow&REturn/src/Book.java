import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Book {

    private String     bookID;
    private String     barcode;
    private String     title;
    private String     author;
    private BookStatus status;

    public Book(String bookID, String barcode, String title, String author, BookStatus status) {
        this.bookID  = bookID;
        this.barcode = barcode;
        this.title   = title;
        this.author  = author;
        this.status  = status;
    }

    public boolean isAvailable() {
        return status == BookStatus.AVAILABLE;
    }

    // ── DATABASE METHODS ─────────────────────────────────────────

    public static List<Book> getAll() {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM book";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) list.add(mapRow(rs));

        } catch (SQLException e) {
            System.out.println("  DB error (Book.getAll): " + e.getMessage());
        }
        return list;
    }

    public static List<Book> getAvailable() {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM book WHERE status = 'AVAILABLE'";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) list.add(mapRow(rs));

        } catch (SQLException e) {
            System.out.println("  DB error (Book.getAvailable): " + e.getMessage());
        }
        return list;
    }

    public static Book getById(String bookID) {
        String sql = "SELECT * FROM book WHERE book_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, bookID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);

        } catch (SQLException e) {
            System.out.println("  DB error (Book.getById): " + e.getMessage());
        }
        return null;
    }

    public void updateStatus() {
        String sql = "UPDATE book SET status = ? WHERE book_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status.name());
            ps.setString(2, bookID);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("  DB error (Book.updateStatus): " + e.getMessage());
        }
    }

    private static Book mapRow(ResultSet rs) throws SQLException {
        return new Book(
                rs.getString("book_id"),
                rs.getString("barcode"),
                rs.getString("title"),
                rs.getString("author"),
                BookStatus.valueOf(rs.getString("status"))
        );
    }

    // ── GETTERS / SETTERS ────────────────────────────────────────
    public String     getBookID()  { return bookID; }
    public String     getBarcode() { return barcode; }
    public String     getTitle()   { return title; }
    public String     getAuthor()  { return author; }
    public BookStatus getStatus()  { return status; }
    public void setStatus(BookStatus status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("%-8s %-28s %-20s [%s]", bookID, title, author, status);
    }
}
