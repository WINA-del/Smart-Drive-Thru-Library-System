import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Reservation {

    private String    reserveID;
    private Customer  customer;
    private Book      book;
    private LocalDate reserveDate;
    private LocalDate expiryDate;
    private boolean   notified;
    private boolean   cancelled;

    public Reservation(String reserveID, Customer customer, Book book) {
        this.reserveID   = reserveID;
        this.customer    = customer;
        this.book        = book;
        this.reserveDate = LocalDate.now();
        this.expiryDate  = reserveDate.plusDays(7);
        this.notified    = false;
        this.cancelled   = false;
    }

    public Reservation(String reserveID, Customer customer, Book book,
                        LocalDate reserveDate, LocalDate expiryDate,
                        boolean notified, boolean cancelled) {
        this.reserveID   = reserveID;
        this.customer    = customer;
        this.book        = book;
        this.reserveDate = reserveDate;
        this.expiryDate  = expiryDate;
        this.notified    = notified;
        this.cancelled   = cancelled;
    }

    public boolean isActive()  { return !cancelled && !isExpired(); }
    public boolean isExpired() { return LocalDate.now().isAfter(expiryDate); }

    // ── DATABASE METHODS ─────────────────────────────────────────

    public static String generateNextID() {
        String sql = "SELECT COUNT(*) AS total FROM reservation";
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) count = rs.getInt("total");
        } catch (SQLException e) {
            System.out.println("  DB error (generateNextID): " + e.getMessage());
        }
        return String.format("RES-%03d", count + 1);
    }

    public void save() {
        String sql = "INSERT INTO reservation (reserve_id, customer_id, book_id, reserve_date, expiry_date, notified, cancelled) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, reserveID);
            ps.setString(2, customer.getCustomerID());
            ps.setString(3, book.getBookID());
            ps.setDate(4, Date.valueOf(reserveDate));
            ps.setDate(5, Date.valueOf(expiryDate));
            ps.setBoolean(6, notified);
            ps.setBoolean(7, cancelled);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("  DB error (Reservation.save): " + e.getMessage());
        }
    }

    public static List<Reservation> getByCustomer(Customer customer) {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservation WHERE customer_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, customer.getCustomerID());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Book b = Book.getById(rs.getString("book_id"));
                list.add(new Reservation(
                        rs.getString("reserve_id"), customer, b,
                        rs.getDate("reserve_date").toLocalDate(),
                        rs.getDate("expiry_date").toLocalDate(),
                        rs.getBoolean("notified"),
                        rs.getBoolean("cancelled")
                ));
            }
        } catch (SQLException e) {
            System.out.println("  DB error (Reservation.getByCustomer): " + e.getMessage());
        }
        return list;
    }

    // ── GETTERS ────────────────────────────────────────────────
    public String    getReserveID()   { return reserveID; }
    public Customer  getCustomer()    { return customer; }
    public Book      getBook()        { return book; }
    public LocalDate getReserveDate() { return reserveDate; }
    public LocalDate getExpiryDate()  { return expiryDate; }
    public boolean   isNotified()     { return notified; }
    public boolean   isCancelled()    { return cancelled; }

    public String getStatus() {
        if (cancelled) return "CANCELLED";
        if (isExpired()) return "EXPIRED";
        return notified ? "NOTIFIED" : "PENDING";
    }

    @Override
    public String toString() {
        return reserveID + " | " + book.getTitle() + " | Expires: " + expiryDate
                + " | " + getStatus();
    }
}
