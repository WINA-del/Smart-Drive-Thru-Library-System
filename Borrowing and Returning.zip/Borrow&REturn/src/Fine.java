import java.sql.*;

public class Fine {

    private static final double RATE    = 0.50;
    private static final double MAX_CAP = 20.00;

    private String  fineID;
    private String  recordID;
    private int     overdueDays;
    private double  amount;
    private boolean isPaid;
    private boolean isExempted;

    // New fine — amount auto-calculated
    public Fine(String fineID, String recordID, int overdueDays) {
        this.fineID      = fineID;
        this.recordID    = recordID;
        this.overdueDays = overdueDays;
        this.amount      = Math.min(overdueDays * RATE, MAX_CAP);
        this.isPaid       = false;
        this.isExempted   = false;
    }

    // Used when loading an existing fine from the database
    public Fine(String fineID, String recordID, int overdueDays,
                double amount, boolean isPaid, boolean isExempted) {
        this.fineID      = fineID;
        this.recordID    = recordID;
        this.overdueDays = overdueDays;
        this.amount      = amount;
        this.isPaid       = isPaid;
        this.isExempted   = isExempted;
    }

    public void markPaid()       { isPaid = true; }
    public void applyExemption() { isExempted = true; }
    public boolean isCapped()    { return (overdueDays * RATE) >= MAX_CAP; }

    // ── DATABASE METHODS ─────────────────────────────────────────

    public void save() {
        String sql = "INSERT INTO fine (fine_id, record_id, overdue_days, amount, is_paid, is_exempted) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, fineID);
            ps.setString(2, recordID);
            ps.setInt(3, overdueDays);
            ps.setDouble(4, amount);
            ps.setBoolean(5, isPaid);
            ps.setBoolean(6, isExempted);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("  DB error (Fine.save): " + e.getMessage());
        }
    }

    public void updateState() {
        String sql = "UPDATE fine SET is_paid = ?, is_exempted = ? WHERE fine_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBoolean(1, isPaid);
            ps.setBoolean(2, isExempted);
            ps.setString(3, fineID);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("  DB error (Fine.updateState): " + e.getMessage());
        }
    }

    public static Fine getByRecordId(String recordID) {
        String sql = "SELECT * FROM fine WHERE record_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, recordID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Fine(
                        rs.getString("fine_id"),
                        rs.getString("record_id"),
                        rs.getInt("overdue_days"),
                        rs.getDouble("amount"),
                        rs.getBoolean("is_paid"),
                        rs.getBoolean("is_exempted")
                );
            }
        } catch (SQLException e) {
            System.out.println("  DB error (Fine.getByRecordId): " + e.getMessage());
        }
        return null;
    }

    // ── GETTERS ────────────────────────────────────────────────
    public String  getFineID()      { return fineID; }
    public String  getRecordID()    { return recordID; }
    public int     getOverdueDays() { return overdueDays; }
    public double  getAmount()      { return amount; }
    public boolean isPaid()         { return isPaid; }
    public boolean isExempted()     { return isExempted; }

    @Override
    public String toString() {
        String state = isPaid ? "PAID" : isExempted ? "EXEMPTED" : "UNPAID";
        return String.format("Fine[%s] Days=%d Amount=RM%.2f Status=%s",
                fineID, overdueDays, amount, state);
    }
}
