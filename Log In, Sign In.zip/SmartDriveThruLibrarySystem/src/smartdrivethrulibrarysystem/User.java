
package smartdrivethrulibrarysystem;

public class User {
    // Attributes
    private String userID;
    private String name;
    private String email;
    private String phoneNumber;

    // Constructor
    public User() {}

    // Getters and Setters
    public String getUserID() { return this.userID; }
    public void setUserID(String id) { this.userID = id; }

    public String getName() { return this.name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return this.email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return this.phoneNumber; }
    public void setPhoneNumber(String phone) { this.phoneNumber = phone; }

    // Polymorphism method
    public String getDetails() {
        return "ID: " + this.userID + ", Name: " + this.name;
    }
}
