
package smartdrivethrulibrarysystem;

public class Customer extends User { // Inheritance
    private String membershipID;
    private String accountStatus;

    public Customer() {
        this.accountStatus = "Active";
    }

    public String getMembershipID() { return this.membershipID; }
    public void setMembershipID(String id) { this.membershipID = id; }

    @Override
    public String getDetails() { // Polymorphism Overriding
        return "Customer Profile\n" + super.getDetails() + "\nStatus: " + this.accountStatus;
    }
}
