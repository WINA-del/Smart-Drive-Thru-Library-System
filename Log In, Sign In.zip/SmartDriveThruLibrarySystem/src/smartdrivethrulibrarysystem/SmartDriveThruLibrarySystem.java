/**
 * Smart Drive-Thru Library System
 * Module : User Management System (Login, Register)
 * ─────────────────────────────────────────────────────────────────
 * OOP Concepts demonstrated:
 * Encapsulation  — Demonstrated by making attributes private (e.g., - username, - password in Account; - userID in User)
 * Inheritance    — Demonstrated by the specialized classes Customer and Librarian extending the base User class 
 * (Customer extends User, Librarian extends User), inheriting common traits like name, email, and phone.
 * Polymorphism   — Demonstrated by method overriding, where Customer and Librarian override the + getDetails(): String 
 * Abstraction    — Demonstrated by treating 'User' as a generalized entity to simplify system interaction, hiding specific 
 * Composition    — Demonstrated by the relationship between User/Librarian and Account; an Account cannot exist meaningfully 
 * Aggregation    — Demonstrated by the UserManagementController holding a reference to the active User (- currentUser: User)
 * ─────────────────────────────────────────────────────────────────
 */
package smartdrivethrulibrarysystem;

public class SmartDriveThruLibrarySystem {
    public static void main(String[] args) {
        System.out.println("Initializing Drive-Thru System Application...");
        
        // Start the application right from the Login window
        LoginFrame startApp = new LoginFrame();
        startApp.setVisible(true);
    }
}
