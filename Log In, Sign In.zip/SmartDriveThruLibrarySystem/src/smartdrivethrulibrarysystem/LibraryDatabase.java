
package smartdrivethrulibrarysystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LibraryDatabase {
    // Database connection details (Updated with your exact database name)
    private final String URL = "jdbc:mysql://localhost:3306/smartdrivethrulibrarysysteminventory";
    private final String USER = "root"; // Default XAMPP username
    private final String PASS = "";     // Default XAMPP password (blank)

    // Method to connect to the database
    private Connection connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (Exception e) {
            System.out.println("Database Connection Failed: " + e.getMessage());
            return null;
        }
    }

    // SQL for Registration (Sign Up)
    public boolean saveUser(String username, String password, String name, String email, String phone, String role) {
        String sql = "INSERT INTO users (username, password, name, email, phone, role) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, name);
            pstmt.setString(4, email);
            pstmt.setString(5, phone);
            pstmt.setString(6, role);
            
            pstmt.executeUpdate();
            System.out.println("User registered in SQL successfully!");
            return true;
        } catch (Exception e) {
            System.out.println("Registration Error: " + e.getMessage());
            return false;
        }
    }

    // SQL for Login
    public boolean validateLogin(String inputUser, String inputPass) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, inputUser);
            pstmt.setString(2, inputPass);
            
            ResultSet rs = pstmt.executeQuery();
            
            // If rs.next() is true, it means a matching row was found!
            return rs.next(); 
            
        } catch (Exception e) {
            System.out.println("Login Error: " + e.getMessage());
            return false;
        }
    }
}