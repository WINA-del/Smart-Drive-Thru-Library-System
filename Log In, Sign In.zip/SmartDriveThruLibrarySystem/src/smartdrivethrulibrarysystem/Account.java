
package smartdrivethrulibrarysystem;

public class Account {
    private String username;
    private String password;
    private boolean activeStatus;

    public Account() {
        this.activeStatus = true;
    }

    // Encapsulation via Getters and Setters
    public String getUsername() { return this.username; }
    public void setUsername(String u) { this.username = u; }

    public String getPassword() { return this.password; }
    public void setPassword(String p) { this.password = p; }
}
