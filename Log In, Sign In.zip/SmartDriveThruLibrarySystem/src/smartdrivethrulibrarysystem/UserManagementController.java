package smartdrivethrulibrarysystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserManagementController {

    static Object currentUser;
    // Database connection details
    private final String URL = "jdbc:mysql://localhost:3306/smartdrivethrulibrarysysteminventory";
    private final String USER = "root"; // Default XAMPP username
    private final String PASS = "";     // Default XAMPP password (blank)

    // Method to connect to the database
    private Connection connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (Exception e) {
            System.out.println("Database Connection Failed: " + e.getMessage());
            return null;
        }
    }

    // SQL for Registration (Sign Up)
    public boolean saveUser(String username, String password, String name, String email, String phone, String role) {
        String sql = "INSERT INTO users (username, password, name, email, phone, role) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, name);
            pstmt.setString(4, email);
            pstmt.setString(5, phone);
            pstmt.setString(6, role);
            
            pstmt.executeUpdate();
            System.out.println("User registered in SQL successfully!");
            return true;
        } catch (Exception e) {
            System.out.println("Registration Error: " + e.getMessage());
            return false;
        }
    }

    // SQL for Login
    public boolean validateLogin(String inputUser, String inputPass) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, inputUser);
            pstmt.setString(2, inputPass);
            
            ResultSet rs = pstmt.executeQuery();
            
            // If rs.next() is true, it means a matching row was found!
            return rs.next(); 
            
        } catch (Exception e) {
            System.out.println("Login Error: " + e.getMessage());
            return false;
        }
    }

    // Method to retrieve full user details after successful login
    public User retrieveUser(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                String role = rs.getString("role");
                User foundUser;
                
                // 1. Check the role and create the correct object type
                if (role.equalsIgnoreCase("Librarian")) {
                    foundUser = new Librarian();
                } else {
                    foundUser = new Customer();
                }
                
                // 2. Fill the object with data from your XAMPP database
                // (Note: we use strings here temporarily to avoid integer conversion errors)
                foundUser.setUserID(rs.getString("userID"));
                foundUser.setName(rs.getString("name"));
                foundUser.setEmail(rs.getString("email"));
                foundUser.setPhoneNumber(rs.getString("phone")); 
                
                return foundUser;
            }
            
        } catch (Exception e) {
            System.out.println("Retrieve User Error: " + e.getMessage());
        }
        
        return null; // Return null if something goes wrong
    }

    boolean loginSystem(String user, String pass) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
