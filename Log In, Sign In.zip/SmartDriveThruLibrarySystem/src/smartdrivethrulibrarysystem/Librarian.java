
package smartdrivethrulibrarysystem;

public class Librarian extends User { // Inheritance
    private String employeeID;
    private String role;

    public Librarian() {
        this.role = "Librarian";
    }

    public String getEmployeeID() { return this.employeeID; }
    public void setEmployeeID(String id) { this.employeeID = id; }

    @Override
    public String getDetails() { // Polymorphism Overriding
        return "Librarian Profile\n" + super.getDetails() + "\nRole: " + this.role;
    }
}
