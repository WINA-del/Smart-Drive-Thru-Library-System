package smart_drive_thru_library_system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

public class DatabaseConnection {
    public static Connection getConnection() {
        Connection conn = null;
        try {
            // This connects to the database you created in phpMyAdmin
            String url = "jdbc:mysql://localhost:3306/LibraryInventoryDB";
            String user = "root";
            String password = ""; // Default XAMPP password is empty
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connection Successful!");
        } catch (Exception e) {
            System.out.println("Connection Failed! " + e.getMessage());
        }
        return conn;
    }
}