package smart_drive_thru_library_system;

public class Book {
    // ENCAPSULATION: Private attributes matching your diagram exactly
    private String bookId;
    private String title;
    private String author;
    private String genre;
    private String isbn;
    private String status;
    private String slotId;

    // CONSTRUCTOR
    public Book(String bookId, String title, String author, String genre, String isbn, String status, String slotId) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.isbn = isbn;
        this.status = status;
        this.slotId = slotId;
    }

    // GETTERS
    public String getBookId() { return bookId; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getGenre() { return genre; }
    public String getIsbn() { return isbn; }
    public String getStatus() { return status; }
    public String getSlotId() { return slotId; }
}