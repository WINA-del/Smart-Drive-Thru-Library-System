package smart_drive_thru_library_system;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InventoryController {
    // This method fetches all books from the database
    public List<Book> getAllBooks() {
        List<Book> bookList = new ArrayList<>();
        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Book");
            
            while (rs.next()) {
                // We create a Book object for every row in the database
                Book b = new Book(
                    rs.getString("bookId"), rs.getString("title"),
                    rs.getString("author"), rs.getString("genre"),
                    rs.getString("isbn"), rs.getString("status"),
                    rs.getString("slotId")
                );
                bookList.add(b);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bookList;
    }
}