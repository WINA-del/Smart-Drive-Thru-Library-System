package smart_drive_thru_library_system;

public class Category {
    private String categoryId;
    private String name;
    private String shelfLayout;

    public Category(String categoryId, String name, String shelfLayout) {
        this.categoryId = categoryId;
        this.name = name;
        this.shelfLayout = shelfLayout;
    }

    public String getCategoryId() { return categoryId; }
    public String getName() { return name; }
    public String getShelfLayout() { return shelfLayout; }
}